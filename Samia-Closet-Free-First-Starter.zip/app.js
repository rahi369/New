import { initializeApp } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-app.js";
import { getAuth, onAuthStateChanged, setPersistence, browserLocalPersistence } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-auth.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBI_7ctv3PGoaknMt2e9Z4o_TKB_fSgxik",
  authDomain: "samia-s-closet-1aac1.firebaseapp.com",
  projectId: "samia-s-closet-1aac1",
  storageBucket: "samia-s-closet-1aac1.firebasestorage.app",
  messagingSenderId: "912430030937",
  appId: "1:912430030937:web:e731293540f1518c4e9148",
  measurementId: "G-TK72HKT7HS"
};

const app=initializeApp(firebaseConfig);
const auth=getAuth(app);
const db=getFirestore(app);
setPersistence(auth,browserLocalPersistence).catch(()=>{});

const fallbackProducts=[
 {id:"demo-w1",name:"Premium Women's Dress",price:850,category:"Women",description:"Elegant everyday fashion piece. Replace this demo item from the Admin/Firebase product collection.",image:"assets/product-placeholder.svg"},
 {id:"demo-m1",name:"Classic Men's Shirt",price:750,category:"Boys / Men",description:"Clean, versatile shirt for boys/men. Replace this demo item from the Admin/Firebase product collection.",image:"assets/product-placeholder.svg"},
 {id:"demo-w2",name:"Soft Everyday Kurti",price:650,category:"Women",description:"Comfort-focused style for daily wear.",image:"assets/product-placeholder.svg"},
 {id:"demo-m2",name:"Premium Casual Tee",price:550,category:"Boys / Men",description:"A simple casual option for the collection.",image:"assets/product-placeholder.svg"}
];

let products=[...fallbackProducts];
let cart=JSON.parse(localStorage.getItem("sc_cart")||"[]");
const $=s=>document.querySelector(s);
const money=n=>"৳"+Number(n||0).toLocaleString("en-BD");
function toast(t){const e=$("#toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2200)}
function saveCart(){localStorage.setItem("sc_cart",JSON.stringify(cart));$("#cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0)}
function modal(html){$("#modalContent").innerHTML=html;$("#modal").classList.remove("hidden")}
function closeModal(){$("#modal").classList.add("hidden")}

async function loadProducts(){
  try{
    const snap=await getDocs(collection(db,"products"));
    const live=snap.docs.map(d=>({id:d.id,...d.data()})).filter(p=>p.visible!==false);
    if(live.length) products=live;
  }catch(e){console.warn("Firestore product load unavailable; using fallback.",e)}
  renderProducts();
}
function renderProducts(){
  const q=($("#search")?.value||"").toLowerCase();
  const c=$("#categoryFilter")?.value||"All";
  const list=products.filter(p=>(c==="All"||p.category===c)&&((p.name||"").toLowerCase().includes(q)));
  $("#productGrid").innerHTML=list.length?list.map(p=>`
  <article class="product-card">
    <img class="product-image" data-image="${p.id}" src="${p.image||"assets/product-placeholder.svg"}" alt="${p.name||"Product"}">
    <div class="product-info"><h3>${p.name}</h3><div class="price">${money(p.price)}</div><div class="muted">${p.category||""}</div>
    <div class="product-actions"><button class="btn ghost" data-details="${p.id}">VIEW DETAILS</button><button class="btn primary" data-buy="${p.id}">ORDER NOW</button></div></div>
  </article>`).join(""):`<div class="empty">No products found.</div>`;
}
function product(id){return products.find(p=>p.id===id)}
function add(id,qty=1){const p=product(id);if(!p)return;const found=cart.find(x=>x.id===id);if(found)found.qty+=qty;else cart.push({id,qty});saveCart();toast("Added to Bag");}
function showDetails(id){
 const p=product(id);if(!p)return;
 modal(`<div class="detail-grid"><div><img class="full-photo" src="${p.image||"assets/product-placeholder.svg"}" alt="${p.name}"></div><div><p class="eyebrow">${p.category||""}</p><h2>${p.name}</h2><h3>${money(p.price)}</h3><p>${p.description||"Product details will appear here."}</p><div class="form"><label>Size<select id="optSize"><option>Default</option><option>S</option><option>M</option><option>L</option><option>XL</option></select></label><button class="btn primary" data-modaladd="${p.id}">ADD TO BAG</button><button class="btn ghost" data-modalbuy="${p.id}">ORDER NOW</button></div></div></div>`);
}
function showCart(){
 const rows=cart.map(x=>{const p=product(x.id);return p?`<div class="order-item"><span>${p.name}<br><small>${money(p.price)} × ${x.qty}</small></span><span><b>${money(p.price*x.qty)}</b><br><button data-remove="${p.id}">Remove</button></span></div>`:""}).join("");
 const subtotal=cart.reduce((a,x)=>{const p=product(x.id);return a+(p?p.price*x.qty:0)},0);
 modal(`<h2>Your Bag</h2>${rows||'<div class="empty">Your bag is empty.</div>'}<hr><div class="order-item"><b>Subtotal</b><b>${money(subtotal)}</b></div>${cart.length?'<button class="btn primary" style="width:100%;margin-top:15px" data-action="checkout">CHECKOUT</button>':""}`);
}
function showOrders(){
 const user=auth.currentUser;
 modal(`<h2>Order History</h2>${user?`<p class="muted">Signed in as ${user.email}</p><div class="empty">Connect your Firestore <code>orders</code> collection and customer rules to display live orders here.</div>`:`<div class="empty">Please sign in to view your orders.</div>`}`);
}
function showCheckout(){
 if(!cart.length){toast("Your Bag is empty");return}
 const subtotal=cart.reduce((a,x)=>{const p=product(x.id);return a+(p?p.price*x.qty:0)},0);
 modal(`<h2>Checkout</h2><p class="muted">Subtotal ${money(subtotal)} · Delivery Moulvibazar ৳50 / Outside Moulvibazar ৳150</p>
 <form id="checkoutForm" class="form"><input name="name" required placeholder="Customer Name"><input name="phone" required placeholder="Phone Number"><textarea name="address" required placeholder="Full Address"></textarea><input name="area" required placeholder="Area (Moulvibazar / Outside Moulvibazar)"><select name="payment"><option>Cash on Delivery</option><option>bKash</option><option>Nagad</option></select><input name="txid" placeholder="Transaction ID (online payment)"><button class="btn primary">PLACE ORDER</button></form>`);
}
function showQuiz(){modal(`<h2>Daily Quiz</h2><p>Quiz interface is ready for Firebase integration.</p><div class="info-card"><b>Production setup</b><p>Questions, attempts and rewards should be stored in Firestore with secure rules. This starter intentionally does not fake successful rewards.</p></div>`)}
document.addEventListener("click",e=>{
 const t=e.target;
 if(t.closest('[data-action="menu"]'))$("#menuPanel").classList.toggle("hidden");
 if(t.closest('[data-action="cart"]'))showCart();
 if(t.closest('[data-action="orders"]'))showOrders();
 if(t.closest('[data-action="close"]')||t.id==="modal")closeModal();
 if(t.closest('[data-action="checkout"]'))showCheckout();
 if(t.closest('[data-action="quiz"]'))showQuiz();
 const d=t.closest("[data-details]");if(d)showDetails(d.dataset.details);
 const b=t.closest("[data-buy]");if(b){add(b.dataset.buy);showCart()}
 const a=t.closest("[data-modaladd]");if(a){add(a.dataset.modaladd);closeModal()}
 const mb=t.closest("[data-modalbuy]");if(mb){add(mb.dataset.modalbuy);showCart()}
 const r=t.closest("[data-remove]");if(r){cart=cart.filter(x=>x.id!==r.dataset.remove);saveCart();showCart()}
 const img=t.closest("[data-image]");if(img){const p=product(img.dataset.image);if(p)modal(`<img class="full-photo" src="${p.image}" alt="${p.name}">`)}
 const cat=t.closest("[data-category]");if(cat){$("#categoryFilter").value=cat.dataset.category;location.hash="#products";renderProducts()}
});
document.addEventListener("submit",e=>{if(e.target.id==="checkoutForm"){e.preventDefault();toast("Demo checkout prepared — connect order write rules before accepting real orders.");}});
$("#search").addEventListener("input",renderProducts);$("#categoryFilter").addEventListener("change",renderProducts);
$("#cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0);
onAuthStateChanged(auth,user=>console.log("Auth state:",user?.email||"signed out"));
loadProducts();
